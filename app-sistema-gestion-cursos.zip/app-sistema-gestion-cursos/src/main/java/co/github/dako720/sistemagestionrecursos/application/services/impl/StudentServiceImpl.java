package co.github.dako720.sistemagestionrecursos.application.services.impl;

import co.github.dako720.sistemagestionrecursos.application.Excepciones.StudentNotFoundException;
import co.github.dako720.sistemagestionrecursos.application.dto.CreateStudentDto;
import co.github.dako720.sistemagestionrecursos.application.services.StudentService;
import co.github.dako720.sistemagestionrecursos.domain.models.Student;
import co.github.dako720.sistemagestionrecursos.domain.repositories.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepository;

    public StudentServiceImpl(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @Override
    public CreateStudentDto create(CreateStudentDto studentDTO) {
        Student student = toModel(studentDTO);
        Student saved = studentRepository.save(student);
        return toDTO(saved);
    }

    @Override
    public CreateStudentDto findById(Long id) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new StudentNotFoundException(id));
        return toDTO(student);
    }

    @Override
    public List<CreateStudentDto> findAll() {
        return studentRepository.findAll().stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public CreateStudentDto update(Long id, CreateStudentDto studentDTO) {
        if (!studentRepository.existsById(id)) {
            throw new StudentNotFoundException(id);
        }
        Student student = toModel(studentDTO);
        student.setStudentId(id);
        Student updated = studentRepository.update(student);
        return toDTO(updated);
    }

    @Override
    public void delete(Long id) {
        if (!studentRepository.existsById(id)) {
            throw new StudentNotFoundException(id);
        }
        studentRepository.deleteById(id);
    }

    private Student toModel(CreateStudentDto dto) {
        return new Student(dto.id(), dto.firstName(), dto.lastName(), dto.email(),
                dto.phoneNumber(), dto.birthDate());
    }

    private CreateStudentDto toDTO(Student student) {
        return new CreateStudentDto(student.getStudentId(), student.getFirstName(), student.getLastName(),
                student.getEmail(), student.getPhoneNumber(), student.getBirthDate());
    }
}
