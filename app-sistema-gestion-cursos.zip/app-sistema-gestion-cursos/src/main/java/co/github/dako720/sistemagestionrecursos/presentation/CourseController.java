package co.github.dako720.sistemagestionrecursos.presentation;

import co.github.dako720.sistemagestionrecursos.application.dto.CreateCourseDto;
import co.github.dako720.sistemagestionrecursos.application.services.CourseService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/courses")
public class CourseController {

    private final CourseService courseService;

    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    @PostMapping
    public ResponseEntity<CreateCourseDto> create(
            @RequestBody CreateCourseDto courseDTO) {

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(courseService.create(courseDTO));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CreateCourseDto> findById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                courseService.findById(id)
        );
    }

    @GetMapping
    public ResponseEntity<List<CreateCourseDto>> findAll() {

        return ResponseEntity.ok(
                courseService.findAll()
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<CreateCourseDto> update(
            @PathVariable Long id,
            @RequestBody CreateCourseDto courseDTO) {

        return ResponseEntity.ok(
                courseService.update(id, courseDTO)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(
            @PathVariable Long id) {

        courseService.delete(id);

        return ResponseEntity.noContent().build();
    }
}