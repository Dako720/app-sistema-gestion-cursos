package co.github.dako720.sistemagestionrecursos.application.services;

import co.github.dako720.sistemagestionrecursos.application.dto.CreateCourseDto;

import java.util.List;

public interface CourseService {

    CreateCourseDto create(CreateCourseDto courseDTO);

    CreateCourseDto findById(Long id);

    List<CreateCourseDto> findAll();

    CreateCourseDto update(Long id, CreateCourseDto courseDTO);

    void delete(Long id);
}
