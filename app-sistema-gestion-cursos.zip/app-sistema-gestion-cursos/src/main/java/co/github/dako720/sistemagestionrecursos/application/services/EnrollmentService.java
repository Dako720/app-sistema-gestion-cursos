package co.github.dako720.sistemagestionrecursos.application.services;

import co.github.dako720.sistemagestionrecursos.application.dto.CreateEnrollmentDto;

import java.util.List;

public interface EnrollmentService {

    CreateEnrollmentDto create(CreateEnrollmentDto enrollmentDTO);

    CreateEnrollmentDto findById(Long id);

    List<CreateEnrollmentDto> findAll();

    CreateEnrollmentDto cancel(Long id);

    void delete(Long id);
}
