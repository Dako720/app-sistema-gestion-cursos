package co.github.dako720.sistemagestionrecursos.application.services;

import co.github.dako720.sistemagestionrecursos.application.dto.CreateStudentDto;

import java.util.List;

public interface StudentService {

    CreateStudentDto create(CreateStudentDto studentDTO);

    CreateStudentDto findById(Long id);

    List<CreateStudentDto> findAll();

    CreateStudentDto update(Long id, CreateStudentDto studentDTO);

    void delete(Long id);
}
