package co.github.dako720.sistemagestionrecursos.infrastructure.repositories;

import co.github.dako720.sistemagestionrecursos.domain.models.Course;
import org.springframework.data.jpa.repository.JpaRepository;

interface CourseJpaRepository extends JpaRepository<Course, Long> {
}
