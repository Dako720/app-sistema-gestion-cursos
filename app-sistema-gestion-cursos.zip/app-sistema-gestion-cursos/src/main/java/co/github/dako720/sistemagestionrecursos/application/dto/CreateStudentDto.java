package co.github.dako720.sistemagestionrecursos.application.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

public record CreateStudentDto(
        @NotNull
        Long id,

        @NotBlank
        String firstName,

        @NotBlank
        String lastName,


        @NotBlank
        @Email
        String email,

        @NotBlank
        String phoneNumber,

        @NotNull
        LocalDate birthDate
) {
}
