package co.github.dako720.sistemagestionrecursos.presentation;

import co.github.dako720.sistemagestionrecursos.application.dto.CreateEnrollmentDto;
import co.github.dako720.sistemagestionrecursos.application.services.EnrollmentService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/enrollments")
public class EnrollmentController {

    private final EnrollmentService enrollmentService;

    public EnrollmentController(EnrollmentService enrollmentService) {
        this.enrollmentService = enrollmentService;
    }

    @PostMapping
    public ResponseEntity<CreateEnrollmentDto> create(
            @RequestBody CreateEnrollmentDto enrollmentDTO) {

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(enrollmentService.create(enrollmentDTO));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CreateEnrollmentDto> findById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                enrollmentService.findById(id)
        );
    }

    @GetMapping
    public ResponseEntity<List<CreateEnrollmentDto>> findAll() {

        return ResponseEntity.ok(
                enrollmentService.findAll()
        );
    }

    @PutMapping("/{id}/cancel")
    public ResponseEntity<CreateEnrollmentDto> cancel(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                enrollmentService.cancel(id)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(
            @PathVariable Long id) {

        enrollmentService.delete(id);

        return ResponseEntity.noContent().build();
    }
}