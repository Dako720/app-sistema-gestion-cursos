package co.github.dako720.sistemagestionrecursos.infrastructure.repositories;

import co.github.dako720.sistemagestionrecursos.domain.models.Enrollment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

interface EnrollmentJpaRepository extends JpaRepository<Enrollment, Long> {
    List<Enrollment> findByCourseId(Long courseId);
}
