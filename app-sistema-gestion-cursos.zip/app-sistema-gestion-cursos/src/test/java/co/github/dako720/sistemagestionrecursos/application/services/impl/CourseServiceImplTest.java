package co.github.dako720.sistemagestionrecursos.application.services.impl;

import co.github.dako720.sistemagestionrecursos.application.Excepciones.CourseNotFoundException;
import co.github.dako720.sistemagestionrecursos.application.dto.CreateCourseDto;
import co.github.dako720.sistemagestionrecursos.domain.models.Course;
import co.github.dako720.sistemagestionrecursos.domain.repositories.CourseRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CourseServiceImplTest {

    @Mock
    private CourseRepository courseRepository;

    private CourseServiceImpl courseService;

    @BeforeEach
    void setUp() {
        courseService = new CourseServiceImpl(courseRepository);
    }

    @Test
    void create_returnsSavedCourseAsDto() {
        Course saved = new Course(1L, "SIS-101", "Java Basico", "Curso de Java", 30);
        when(courseRepository.save(org.mockito.ArgumentMatchers.any(Course.class))).thenReturn(saved);

        CreateCourseDto result = courseService.create(new CreateCourseDto(null, "SIS-101", "Java Basico", "Curso de Java", 30));

        assertThat(result.id()).isEqualTo(1L);
        assertThat(result.code()).isEqualTo("SIS-101");
    }

    @Test
    void findById_throwsWhenCourseDoesNotExist() {
        when(courseRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> courseService.findById(99L))
                .isInstanceOf(CourseNotFoundException.class);
    }
}
