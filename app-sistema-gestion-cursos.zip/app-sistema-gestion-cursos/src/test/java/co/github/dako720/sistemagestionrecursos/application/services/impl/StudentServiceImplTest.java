package co.github.dako720.sistemagestionrecursos.application.services.impl;

import co.github.dako720.sistemagestionrecursos.application.Excepciones.StudentNotFoundException;
import co.github.dako720.sistemagestionrecursos.application.dto.CreateStudentDto;
import co.github.dako720.sistemagestionrecursos.domain.models.Student;
import co.github.dako720.sistemagestionrecursos.domain.repositories.StudentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class StudentServiceImplTest {

    @Mock
    private StudentRepository studentRepository;

    private StudentServiceImpl studentService;

    @BeforeEach
    void setUp() {
        studentService = new StudentServiceImpl(studentRepository);
    }

    @Test
    void create_mapsPhoneNumberAndBirthDateIndependently() {
        LocalDate birthDate = LocalDate.of(2000, 5, 20);
        Student saved = new Student(1L, "Ana", "Gomez", "ana@correo.com", "3001234567", birthDate);
        when(studentRepository.save(org.mockito.ArgumentMatchers.any(Student.class))).thenReturn(saved);

        CreateStudentDto result = studentService.create(
                new CreateStudentDto(null, "Ana", "Gomez", "ana@correo.com", "3001234567", birthDate));

        assertThat(result.phoneNumber()).isEqualTo("3001234567");
        assertThat(result.birthDate()).isEqualTo(birthDate);
    }

    @Test
    void delete_throwsWhenStudentDoesNotExist() {
        when(studentRepository.existsById(5L)).thenReturn(false);

        assertThatThrownBy(() -> studentService.delete(5L))
                .isInstanceOf(StudentNotFoundException.class);
    }
}
